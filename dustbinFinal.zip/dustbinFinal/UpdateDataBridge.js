const request = require('request');
const mqtt = require('mqtt');
const client = mqtt.connect('mqtt://18.236.170.110:1883');

client.on('connect', ()=>{
    console.log('mqtt broker connected');
    client.subscribe('dustbin');
    console.log("subscribed to topic : dustbin");
  });

  client.on('message',(topic,message)=>{

    console.log(message.toString());

    data={
        deviceId:"dust2",
        data:message.toString()

    }

    var options = {
        uri: "http://localhost:3000/device/updateDevice",
        headers: {
          'Content-Type': "application/json"
      
      },
      body:JSON.stringify(data)
      };

    request.post(options, (err, res, body) => {
        console.log("posted : "+body);
        var inbound = JSON.parse(body);
        if(err)
        console.log(err);
        if (inbound.sucess){
            console.log(inbound.msg);
          }
          else{
            console.log(inbound.msg);
          }});
    })