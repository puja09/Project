const mongoose = require('mongoose');

const DeviceSchema = {
    deviceName: {
        type:String,
        required: true
    },
    deviceId: {
        type: String,
        required: true
    },
    data:{
        type:String,
        required:true
    },
    pinCode: {
        type: String,
        required: true
    },
    deviceKey: {
        type: String,
        required: true
    },
    timeStamp:{
        type:Number,
        default:0
    }

}

const DEVICE = module.exports = mongoose.model("DEVICE", DeviceSchema);

module.exports.addDevice=function(device,callback){
    DEVICE.create(device,callback);
};

module.exports.getAllData=function(callback){
    DEVICE.find(callback);
};

module.exports.updateData=function(device,callback){
    query1={
        data:device.data,
        timeStamp:((Date.now())/1000).toFixed()
    }
    DEVICE.findByIdAndUpdate(device._id,query1,callback)

}

module.exports.getDeviceById=function(device,callback){
    query={
        deviceId:device,
    }
    DEVICE.findOne(query,callback);
}

module.exports