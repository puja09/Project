const mongoose = require('mongoose');
var uid=require('uid');
const locationSchema = mongoose.Schema({
    locationName: {
        type:String,
        required: true
    },
    pinCode: {
        type: String,
        required: true
    },
    uidKey: {
        type: String,
        required: true
    }

});

const LOCATION = module.exports = mongoose.model("LOCATION", locationSchema);

module.exports.getAllLocations = function (callback) {
   LOCATION.find(callback); 
};

module.exports.getLocationById = function(pinCode, callback) {//
    query= {
        pinCode:pinCode//
    }
LOCATION.findOne(query,callback)
}

module.exports.addLocation = function(location, callback) {
    query= {
        locationName:location.locationName,
        pinCode:location.pinCode,
        uidKey:uid(10)
    }
    LOCATION.create(query, callback);
};
module.exports.remove = function (location, callback) {
    LOCATION.findByIdAndRemove(location.id, callback);//
};

//