var express = require('express');
var router = express.Router();
const DEVICE = require('../model/deviceModel');
const LOCATION = require('../model/locationModel');


var uid = require('uid');


/* GET home page. */
router.get('/', function (req, res, next) {
    DEVICE.getAllData((err, devices) => {
        if (err) {
            res.json({
                success: false,
                msg: err
            });
        }
        else {
            res.json({
                success: true,
                msg: devices
            })
        }
    });
});


router.post('/addDevice', (req, res) => {
    if (!req.body.deviceName || !req.body.pinCode || !req.body.deviceId || !req.body.data) {
        res.json({
            success: false,
            msg: 'Insufficient data!'

        });
    }
    else {
        DEVICE.getDeviceById(req.body.deviceId, (err, recDevice) => {
            if (err) {
                res.json({
                    "success": false,
                    "msg": err
                })
            }
            else {
                if (recDevice) {
                    res.json({
                        success: false,
                        msg: "device already exist"
                    })
                }
                else {
                    toSend = {
                        deviceName: req.body.deviceName,
                        pinCode: req.body.pinCode,
                        data: req.body.data,
                        deviceId: req.body.deviceId,
                        deviceKey: uid(10)
                    }

                    DEVICE.addDevice(toSend, (err) => {
                        if (err) {
                            res.json({
                                success: false,
                                msg: err
                            })
                        }
                        else {
                            res.json({
                                success: true,
                                msg: "new device added"// {
                                // msg: "new sensor added",
                                //key: uid(11)
                                //}
                            });

                        }
                    })

                }
            }
        })
    }
})
router.post('/updateDevice', (req, res) => {
    if (!req.body.deviceId || !req.body.data) {
        res.json({
            success: false,
            msg: "insufficient data"
        })
    }
    else {
        DEVICE.getDeviceById(req.body.deviceId, (err, recDevice) => {
            if (err) {
                res.json({
                    "success": false,
                    "msg": err
                })
            }
            else {
                if (recDevice) {
                    tosend = {
                        _id: recDevice._id,
                        data: req.body.data
                    }
                    DEVICE.updateData(tosend, (err) => {
                        if (err) {
                            res.json({
                                success: false,
                                msg: err
                            })
                        }
                        else {
                            res.json({
                                success: true,
                                msg: "user data updated"
                            })
                        }
                    })
                }
            }
        })
    }
})


module.exports = router;