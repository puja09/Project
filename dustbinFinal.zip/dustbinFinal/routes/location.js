var express = require('express');
var router = express.Router();
const LOCATION = require("../model/locationModel")

/* GET users listing. */
router.get('/', (req, res) => {
  LOCATION.getAllLocations((err, location) => {
    if (err) {
      res.json({
        success: false,
        msg: err
      });
    }
    else {
      res.json({
        success: true,
        msg: location
      });
    }
  });
});

router.post("/addLocation", (req, res) => {
  if (!req.body.locationName || !req.body.pinCode) {
    res.json({
      success: false,
      msg: "Insufficient data"
    });
  }
  else {
    LOCATION.getLocationById(req.body.pinCode, (err, location) => {
      if (err) {
        res.json({
          success: false,
          msg: err
        });
      }
      else {
        if (location) {
          res.json({
            success: false,
            msg: "location already exist.!"
          });
        }
        else {
          LOCATION.addLocation(req.body, (err) => {
            if (err) {
              res.json({
                success: false,
                msg: err
              });
            }
            else {
              res.json({
                success: true,
                msg: "Location Added Successfully.!"
              });
            }

          });
        }
      }
    })
  }

});

router.post("/removeloc", (req, res) => {
  if (!req.body.locationName || !req.body.pinCode) {
    res.json({
      success: false,
      msg: "Insufficient data"
    });
  }
  else {
    LOCATION.getLocationById(req.body.pinCode, (err, reqlocation) => {
      if (err) {
        res.json({
          success: false,
          msg: err
        });
      }
      else {
        if (reqlocation) {
          body = {
            id:_id
          }
          LOCATION.remove(body, (err) => {
            if (err) {
              res.json({
                success: false,
                msg: err
              });
            }
            else {
              res.json({
                success: true,
                msg: "location Deleted.!"
              });
            }
          });
        }
      }
    });
  }
});



module.exports = router;
