var express = require('express');
var router = express.Router();
const DEVICE = require('../models/devices');
const USER = require('../models/users');
var uid = require('uid');

var mqtt = require('mqtt');
var client = mqtt.connect('mqtt://18.188.167.6:1883')


router.get('/', function (req, res) {
    DEVICE.getAllDevice((err, recvDev) => {
        if (err) {
            res.json({
                success: false,
                msg: err
            })
        }
        else {
            res.json({
                success: true,
                msg: recvDev
            })
        }
    });
});

router.post("/adddevice", (req, res) => {
    if (!req.body.deviceName || !req.body.username || !req.body.apiKey)
        res.json({
            success: false,
            msg: 'incomplete data'
        });
    else {
        USER.findUserByUsername(req.body.username, (err, recvUser) => {
            if (err)
                res.json({
                    success: false,
                    msg: 'invalid user'
                });
            else {
                if (req.body.apiKey != recvUser.apiKey) {
                    res.json({
                        success: false,
                        msg: "Unauthorisd User"
                    });
                }
                else {
                    let device = {
                        devicename: req.body.deviceName,
                        deviceId: req.body.deviceId,
                        username: req.body.username,
                        unit: req.body.unit
                    }
                    DEVICE.addDevice(device, (err) => {
                        if (err)
                            res.json({
                                success: false,
                                msg: err
                            });
                        else
                            res.json({
                                success: true,
                                msg: 'device added'
                            });
                    });

                }
            }
        })
    }
});


router.post("/updatedevice", (req, res) => {
    if (!req.body._id || !req.body.reading || !req.body.interval)
        res.json({
            success: false,
            msg: 'incomplete data'
        });
    else {
        device = {
            _id: req.body._id,
            readings: req.body.reading,
            username: req.body.username,
            interval: req.body.interval
        }
        if (req.body.reading < 30) {
            client.publish('sensor', "on", () => {
                console.log('Pump is getting on');
            });
        }
        else {
            client.publish('sensor', "off", () => {
            });
        }
        DEVICE.updateDeviceData(device, (err) => {
            if (err)
                res.json({
                    success: false,
                    msg: err
                });
            else
                res.json({
                    success: true,
                    msg: 'device update'
                });
        })
    }
});

router.post('/deleteDevice', (req, res) => {
    if (!req.body._id || !req.body.apiKey || !req.body.username)
        res.json({
            success: false,
            msg: 'incomplete data'
        });
    else {
        USER.findUserByUsername(req.body.username, (err, recvUser) => {
            if (err)
                res.json({
                    success: false,
                    msg: 'invalid user'
                });
            else {
                if (req.body.apiKey != recvUser.apiKey) {
                    res.json({
                        success: false,
                        msg: "Unauthorisd User"
                    });
                }
                else {
                    DEVICE.deleteDevices(req.body._id, (err) => {
                        if (err) {
                            res.json({
                                success: false,
                                msg: err
                            });
                        }
                        else {

                            res.json({
                                success: true,
                                msg: "Device Deleted"
                            });
                        }
                    })
                }
            }
        });
    }
});


module.exports = router;