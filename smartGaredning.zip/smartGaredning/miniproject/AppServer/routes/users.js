var express = require('express');
var router = express.Router();
var USER = require('../models/users');
var uid = require('uid');

/* GET users listing. */
router.get('/', function(req, res, next) {
  USER.getAllUsers((err,recvUsers)=>{
    if(err){
      res.json({
        success:false,
        msg:err
      })
    }
    else{
      res.json({
        success:true,
        msg:recvUsers
      });      
    }
  })
});

router.post('/addUser',function(req,res){
  if (!req.body.username || !req.body.name) {
    res.json({
      success: false,
      msg: "insufficient data"
    });
  }
  else {
    USER.findUserByUsername(req.body.username, (err,recvUser) => {
        if(recvUser) {
          res.json({
            success: false,
            msg: "This username already exists"
          })
      }
      else {
       var api = uid(10);
        var toSave={
          name:req.body.name,
          username:req.body.username,
          apiKey:api
        }
          USER.addUser(toSave, (err) => {
            if (err) {
              res.json({
                success: false,
                msg: err
              });
            }
            else {
              res.json({
                success: true,
                msg: "User sucessfully added",
                apiKey:api
              });
            }
          })
        }
      })
  }
})

router.post('/deleteUser', function(req,res){
  if (!req.body.username || !req.body.apiKey) {
    res.json({
      success: false,
      msg: "insufficient data"
    });
    }
    else {
      USER.findUserByApi(req.body.apiKey, (err, recvUser) => {
        if (err) {
          res.json({
            success: false,
            msg: "User not found"
          });
        }
        else {
          USER.removeUser(recvUser._id, (err) => {
            if (err) {
              res.json({
                success: false,
                msg: "User not found"
              });
            }
            else {
              res.json({
                success: true,
                msg: "User successfully deleted"
              });
            }
          });
        }
      });
    }







})


module.exports = router;
