var express = require('express');
var router = express.Router();
var mqtt = require('mqtt');

var client = mqtt.connect('mqtt://18.188.167.6:1883')

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});


router.post('/',(req,res)=>{
    console.log(req.body.val);
    
client.publish('sensor',(req.body.val).toString(),()=>{
    console.log('Data Sent to Device');
})
res.json({
    sucess:true,
    msg:'Interval changed'
})
})
module.exports = router;