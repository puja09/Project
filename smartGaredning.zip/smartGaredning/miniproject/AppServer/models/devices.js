const mongoose = require('mongoose');

//Schema for sensor data
const DeviceSchema = mongoose.Schema({
    
   deviceName:{
       type:String,
       default:'Soil Moisture'
   },
    username:{
        type:String,
        required:true
    },
    readings:
    {
      type:String,
      default:0
    },
    unit:
    {
        type:String,
        default:'cubic metre'
    },
    interval:
    {
        type:Number,
        default:5
    },
    timestamp:{
        type:String,
        default:Date.now()/1000
    }
});

//Naming and exporting the data mongoose model:

const DEVICE = module.exports = mongoose.model('Devices',DeviceSchema);

module.exports.getAllDevice = function(callback){
    DEVICE.find(callback);
}

//Method to add Device:
module.exports.addDevice=function(data,callback){    
    DEVICE.create(data,callback);
}

module.exports.findDeviceByUsername = function(Username,callback){
    var query = {
        username:Username
    }
    DEVICE.find(query,callback)
}
module.exports.updateDeviceData = function(data,callback){
    var toSave= {
        readings:data.readings
    }
    DEVICE.findByIdAndUpdate(data._id,toSave,callback);
}

module.exports.findDeviceByName = function(data,callback){
    var query = {
        username:data.username
    }
    DEVICE.findOne(query,callback);
}

module.exports.deleteDevices= function(data,callback){
    DEVICE.findByIdAndRemove(data._id,callback);

}
